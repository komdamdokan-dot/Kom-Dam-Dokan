<?php
declare(strict_types=1);

$sample = __DIR__ . '/config.sample.php';

if (!file_exists($sample)) {
    throw new RuntimeException('Missing config.sample.php');
}

return require $sample;
