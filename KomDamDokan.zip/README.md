﻿# Kom Dam Dokan

Native PHP + PDO ecommerce project for InfinityFree-style hosting. It includes Gmail-only OTP registration and password reset, product browsing, cart, checkout with COD, wishlist, reviews, blog, and a responsive admin panel.

## Included files
- `database.sql`: schema and starter data.
- `install.php`: creates tables and seeds admin/settings data.
- `includes/config.sample.php`: copy and edit as `includes/config.php`.
- `admin/`: separate admin login and management pages.

## Default admin login
- Email: `komdamdokan@gmail.com`
- Password: `Sakib@7890`

## Installation
1. Upload all files to your hosting root.
2. Create a MySQL database from InfinityFree control panel.
3. Edit `includes/config.php` with your InfinityFree MySQL host, database name, username, and password.
4. Visit `install.php` in the browser and click install.
5. Delete `install.php` after success.

## Gmail SMTP setup
1. Turn on 2-step verification for the Gmail account.
2. Create a Google App Password from the Google account security page.
3. Put SMTP host `smtp.gmail.com`, port `587`, Gmail address, and the app password into Admin > Settings.
4. If your host blocks SMTP ports, use the host-provided mail relay or switch the mail function implementation to PHPMailer SMTP.

## InfinityFree notes
- Use the MySQL hostname given by InfinityFree, not `localhost`.
- Keep uploaded images optimized; the admin image upload already converts to WebP and resizes to max 500px wide.
- Enable `mod_rewrite` support and keep `.htaccess` in the project root.

## Current structure
- Frontend: `index.php`, `search.php`, `product.php`, `cart.php`, `checkout.php`, `order-history.php`, `order-details.php`, `wishlist.php`, `blog.php`, `blog-detail.php`, `login.php`, `register.php`, `forgot-password.php`, `verify-otp.php`, `reset-password.php`, `profile.php`
- Admin: `admin/index.php`, `admin/products.php`, `admin/add-product.php`, `admin/edit-product.php`, `admin/orders.php`, `admin/order-detail.php`, `admin/users.php`, `admin/edit-user.php`, `admin/categories.php`, `admin/reviews.php`, `admin/coupons.php`, `admin/settings.php`, `admin/blog.php`, `admin/backup.php`

## Important notes
- This code uses PDO prepared statements, CSRF tokens, `password_hash()`, login throttling, and WebP image processing.
- The mail helper is located in `includes/mail.php`.
- For production, set `debug` to `false` in `includes/config.php`.
